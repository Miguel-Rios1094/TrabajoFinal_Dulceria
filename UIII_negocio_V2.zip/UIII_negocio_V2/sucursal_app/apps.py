from django.apps import AppConfig


class SucursalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sucursal_app'
